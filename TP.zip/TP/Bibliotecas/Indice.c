#include "Indice.h"

void ind_crear(t_indice* ind, size_t tam_clave, int (*cmp)(const void*, const void*))
{
    crearArbol(&ind->ar_ind);
    ind->tamClave = tam_clave;
    ind->comp = cmp;
}

int ind_insertar(t_indice* ind, void *clave, unsigned nro_reg)
{
    reg_generico reg;

    reg.clave = malloc(ind->tamClave);
    if(!reg.clave)
        return ERROR;

    memcpy(reg.clave, clave, ind->tamClave);
    reg.nro_reg = nro_reg;

    if(!insertarOrdenadoArbol(&ind->ar_ind, &reg, sizeof(reg_generico), cmpRegGenerico, ind))
    {
        free(reg.clave);
        return ERROR;
    }

    return OK;
}

int ind_eliminar(t_indice* ind, void *clave, unsigned *nro_reg)
{
    reg_generico reg;
    void *claveBuscada;

    claveBuscada = malloc(ind->tamClave);

    if(!claveBuscada)
        return ERROR;

    memcpy(claveBuscada, clave, ind->tamClave);

    reg.clave = claveBuscada;

    if(!eliminarElementoArbol(&ind->ar_ind, &reg, sizeof(reg_generico), cmpRegGenerico, ind, eliminarRegistroIndice))
    {
        free(claveBuscada);
        return ERROR;
    }

    *nro_reg = reg.nro_reg;
    free(claveBuscada);

    return OK;
}

int ind_buscar(const t_indice* ind, void *clave, unsigned *nro_reg)
{
    reg_generico reg;
    T_Nodo **enc;
    void *claveBuscada;

    claveBuscada = malloc(ind->tamClave);

    if(!claveBuscada)
        return ERROR;

    memcpy(claveBuscada, clave, ind->tamClave);

    reg.clave = claveBuscada;

    enc = buscarNodoArbol(&ind->ar_ind, &reg, cmpRegGenerico, (t_indice*)ind);

    if(!enc)
    {
        free(claveBuscada);
        return ERROR;
    }

    *nro_reg = ((reg_generico*)(*enc)->info)->nro_reg;

    free(claveBuscada);

    return OK;
}

int ind_cargar(t_indice* ind, const char* path)
{
    FILE *pf;
    ctx_indice ctx;
    long tamArchivo;
    unsigned cantReg;

    pf = fopen(path, "rb");
    if(!pf)
        return ERROR;

    fseek(pf, 0, SEEK_END);
    tamArchivo = ftell(pf);

    cantReg = tamArchivo / (ind->tamClave + sizeof(unsigned));

    rewind(pf);

    ctx.pf = pf;
    ctx.tamClave = ind->tamClave;

    if(!cargarDesdeDatosOrdenadosRec(&ind->ar_ind, &ctx, leerRegistroIndice, 0, cantReg - 1, sizeof(reg_generico)))
    {
        fclose(pf);
        vaciarArbol(&ind->ar_ind, eliminarRegistroIndice);
        return ERROR;
    }

    fclose(pf);

    return OK;
}

int ind_grabar(const t_indice* ind, const char* path)
{
    FILE *pf;
    ctx_indice ctx;

    pf = fopen(path, "wb");

    if(!pf)
        return ERROR;

    ctx.pf = pf;
    ctx.tamClave = ind->tamClave;

    recorrerOrdenArbol((T_Arbol*)&ind->ar_ind, grabarRegistroIndice, &ctx);

    fclose(pf);

    return OK;
}

void ind_vaciar(t_indice* ind)
{
    vaciarArbol(&ind->ar_ind, eliminarRegistroIndice);
}

int ind_recorrer(const t_indice* ind, void (*accion)(const void *, unsigned, void *), void* param)
{
    ctx_recorrer ctx;

    ctx.accion = accion;
    ctx.param = param;

    recorrerOrdenArbol(&ind->ar_ind, recorrerRegistroIndice, &ctx);

    return OK;
}

void eliminarRegistroIndice(void *info)
{
    reg_generico *reg = (reg_generico*)info;

    free(reg->clave);
}

int cmpRegGenerico(const void *a, const void *b, void *ctx)
{
    t_indice *ind = ctx;

    const reg_generico *r1 = a;
    const reg_generico *r2 = b;

    return ind->comp(r1->clave, r2->clave);
}

int leerRegistroIndice(void *ctx, void *info, unsigned pos)
{
    ctx_indice *c = (ctx_indice *)ctx;
    reg_generico *reg = (reg_generico *)info;

    fseek(c->pf, pos * (c->tamClave + sizeof(unsigned)), SEEK_SET);

    reg->clave = malloc(c->tamClave);
    if(!reg->clave)
        return ERROR;

    if(fread(reg->clave, c->tamClave, 1, c->pf) != 1)
    {
        free(reg->clave);
        return ERROR;
    }

    if(fread(&reg->nro_reg, sizeof(unsigned), 1, c->pf) != 1)
    {
        free(reg->clave);
        return ERROR;
    }

    return OK;
}

void grabarRegistroIndice(void *info, void *ctx)
{
    ctx_indice *c = (ctx_indice *)ctx;
    reg_generico *reg = (reg_generico *)info;

    fwrite(reg->clave, c->tamClave, 1, c->pf);
    fwrite(&reg->nro_reg, sizeof(unsigned), 1, c->pf);
}

void recorrerRegistroIndice(void *info, void *ctx)
{
    ctx_recorrer *c = (ctx_recorrer *)ctx;
    reg_generico *reg = (reg_generico *)info;

    c->accion(reg->clave, reg->nro_reg, c->param);
}
