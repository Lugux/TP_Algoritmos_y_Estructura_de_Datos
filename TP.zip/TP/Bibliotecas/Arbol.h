#ifndef ARBOL_H_INCLUDED
#define ARBOL_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define OK 1
#define ERROR 0

#define MINIMO(X,Y) ((X)<(Y)?(X):(Y))
#define MAXIMO(X,Y) ((X)>(Y)?(X):(Y))

#define reservarMemoriaNodo( X , Y , Z , W ) (                             \
              ( ( X ) = (T_Nodo*)malloc( Y ) ) == NULL ||              \
              ( ( Z ) = malloc( W ) ) == NULL   ?                          \
                    free( X ), 0 : 1  )

typedef struct S_Nodo
{
    void *info;
    size_t tamInfo;
    struct S_Nodo *izq, *der;
}T_Nodo;

typedef T_Nodo* T_Arbol;

void crearArbol(T_Arbol* pa);
int insertarOrdenadoArbol(T_Arbol *pa, void *pd, size_t tam, int (*cmp)(const void*, const void*, void*), void *ctx);
void recorrerOrdenArbol(const T_Arbol * pa, void (*accion)(void*, void*), void* param);
void recorrerPreordenArbol(const T_Arbol * pa, void (*accion)(void*, void*), void* param);
void recorrerPosordenArbol(const T_Arbol * pa, void (*accion)(void*, void*), void* param);
unsigned contarNodosArbolBin(const T_Arbol *pa);
unsigned alturaArbolBin(const T_Arbol *pa);
unsigned esBalanceado(const T_Arbol *pa);
int esCompletoHastaNivel(const T_Arbol *pa, int n);
unsigned cantNodosHastaNivel(const T_Arbol *pa, int n);
int eliminarElementoArbol(T_Arbol *p, void *d, unsigned tam, int (*cmp)(const void*, const void*, void*), void *ctx, void(*eliminarDato)(void*));
int eliminarRaizArbol(T_Arbol *pa, void(*eliminarDato)(void*));
T_Nodo** mayorNodoArbol(const T_Arbol *pa);
T_Nodo** menorNodoArbol(const T_Arbol *pa);
T_Nodo** buscarNodoArbol(const T_Arbol *pa, const void* pd, int (*cmp)(const void*, const void*, void*), void *ctx);
void vaciarArbol(T_Arbol *pa, void(*eliminarDato)(void*));
int cargarDesdeDatosOrdenadosRec(T_Arbol *pa, void * pf, int (*leer)(void *, void *, unsigned ), int li, int ls, size_t tam);
int leerDesdeArchivoBin(void *, void *, unsigned);

#endif // ARBOL_H_INCLUDED
