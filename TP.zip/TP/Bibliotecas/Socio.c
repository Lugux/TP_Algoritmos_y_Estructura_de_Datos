#include "Socio.h"

int validarDNI(long dni)
{
    return dni > 10000 && dni < 100000000;
}

int validarFechaNac(T_Fecha *f, T_Fecha *fAct)
{
    if(!validarFecha(f))
        return ERROR;

    if(compFechas(f, fAct) > 0)
        return ERROR;

    return OK;
}

int validarSexo(char s)
{
    return s=='M' || s=='F' || s=='O';
}

int validarFechaAfiliacion(T_Socio *socio, T_Fecha *fAct)
{
    if(!validarFecha(&socio->fAfi))
        return ERROR;

    if(compFechas(&socio->fAfi, &socio->fNac) < 0)
        return ERROR;

    if(compFechas(&socio->fAfi, fAct) > 0)
        return ERROR;

    return OK;
}

int esMenor(T_Socio *socio, T_Fecha *fAct)
{
    int edad=fAct->anio-socio->fNac.anio;

    if(fAct->mes < socio->fNac.mes || (fAct->mes==socio->fNac.mes && fAct->dia<socio->fNac.dia))
        edad--;

    return edad<18? MENOR: ADULTO;
}

int validarCategoria(T_Socio *socio, T_Fecha *fAct)
{
    if(strcmp(socio->cat,"MENOR")==0)
        return esMenor(socio,fAct) == MENOR? OK: ERROR;

    if(strcmp(socio->cat,"CADETE")==0)
        return OK;

    if(strcmp(socio->cat,"ADULTO")==0)
        return esMenor(socio,fAct) == ADULTO? OK: ERROR;

    if(strcmp(socio->cat,"VITALICIO")==0)
        return OK;

    if(strcmp(socio->cat,"HONORARIO")==0)
        return OK;

    if(strcmp(socio->cat,"JUBILADO")==0)
        return esMenor(socio,fAct) == ADULTO? OK: ERROR;

    return ERROR;
}

int validarFechaUltimaCuota(T_Socio *socio, T_Fecha *fAct)
{
    if(!validarFecha(&socio->fUltCuota))
        return ERROR;

    if(compFechas(&socio->fUltCuota,&socio->fAfi)<0)
        return ERROR;

    if(compFechas(&socio->fUltCuota,fAct)>0)
        return ERROR;

    return OK;
}

int validarEstado(char e)
{
    return e=='A' || e=='B';
}

int validarFechaBaja(T_Socio *socio, T_Fecha *fAct)
{
    if(socio->estado == 'A')
    {
        return socio->fBaja.dia == 0 &&
               socio->fBaja.mes == 0 &&
               socio->fBaja.anio == 0;
    }

    if(socio->estado == 'B')
    {
        if(!validarFecha(&socio->fBaja))
            return ERROR;

        if(compFechas(&socio->fBaja, &socio->fAfi) < 0)
            return ERROR;

        if(compFechas(&socio->fBaja, fAct) > 0)
            return ERROR;

        return OK;
    }

    return ERROR;
}

int validarApellido(const char *ape)
{
    return *ape != '\0';
}

int validarNombre(const char *nom)
{
    return *nom != '\0';
}

int validarSocio(T_Socio *socio, T_Fecha *fAct)
{
    if(!validarDNI(socio->dni))
        return ERR_DNI;

    if(!validarApellido(socio->ape))
        return ERR_APELLIDO;

    if(!validarNombre(socio->nom))
        return ERR_NOMBRE;

    if(!validarFechaNac(&socio->fNac, fAct))
        return ERR_FECHA_NAC;

    if(!validarSexo(socio->sexo))
        return ERR_SEXO;

    if(!validarFechaAfiliacion(socio, fAct))
        return ERR_FECHA_AFI;

    if(!validarCategoria(socio, fAct))
        return ERR_CATEGORIA;

    if(!validarFechaUltimaCuota(socio, fAct))
        return ERR_FECHA_CUOTA;

    if(!validarEstado(socio->estado))
        return ERR_ESTADO;

    if(!validarFechaBaja(socio, fAct))
        return ERR_FECHA_BAJA;

    return OK;
}

int leerSocioTxt(T_Socio *socio, FILE *pf)
{
    char linea[256];
    char *ini, *fin;

    if(!fgets(linea, sizeof(linea), pf))
        return FIN_ARCH;

    if((fin = strchr(linea, '\n')) != NULL)
        *fin = '\0';

    /*================= FECHA BAJA =================*/

    fin = strrchr(linea, ',');

    if(!fin)
        return REG_ERROR;

    ini = fin + 1;

    if(*ini == '\0')
    {
        socio->fBaja.dia = 0;
        socio->fBaja.mes = 0;
        socio->fBaja.anio = 0;
    }
    else
    {
        if(sscanf(ini,"%d/%d/%d",
                  &socio->fBaja.dia,
                  &socio->fBaja.mes,
                  &socio->fBaja.anio) != 3)
            return REG_ERROR;
    }

    *fin = '\0';

    /*================= ESTADO =================*/

    fin = strrchr(linea, ',');

    if(!fin)
        return REG_ERROR;

    socio->estado = *(fin + 1);

    *fin = '\0';

    /*================= ULTIMA CUOTA =================*/

    fin = strrchr(linea, ',');

    if(!fin)
        return REG_ERROR;

    if(sscanf(fin + 1,"%d/%d/%d",
              &socio->fUltCuota.dia,
              &socio->fUltCuota.mes,
              &socio->fUltCuota.anio) != 3)
        return REG_ERROR;

    *fin = '\0';

    /*================= CATEGORIA =================*/

    fin = strrchr(linea, ',');

    if(!fin)
        return REG_ERROR;

    strcpy(socio->cat, fin + 1);

    *fin = '\0';

    /*================= FECHA AFILIACION =================*/

    fin = strrchr(linea, ',');

    if(!fin)
        return REG_ERROR;

    if(sscanf(fin + 1,"%d/%d/%d",
              &socio->fAfi.dia,
              &socio->fAfi.mes,
              &socio->fAfi.anio) != 3)
        return REG_ERROR;

    *fin = '\0';

    /*================= SEXO =================*/

    fin = strrchr(linea, ',');

    if(!fin)
        return REG_ERROR;

    socio->sexo = *(fin + 1);

    *fin = '\0';

    /*================= FECHA NACIMIENTO =================*/

    fin = strrchr(linea, ',');

    if(!fin)
        return REG_ERROR;

    if(sscanf(fin + 1,"%d/%d/%d",
              &socio->fNac.dia,
              &socio->fNac.mes,
              &socio->fNac.anio) != 3)
        return REG_ERROR;

    *fin = '\0';

    /*================= NOMBRE =================*/

    fin = strrchr(linea, ',');

    if(!fin)
        return REG_ERROR;

    strcpy(socio->nom, fin + 1);

    *fin = '\0';

    /*================= APELLIDO =================*/

    fin = strrchr(linea, ',');

    if(!fin)
        return REG_ERROR;

    strcpy(socio->ape, fin + 1);

    *fin = '\0';

    /*================= DNI =================*/

    socio->dni = atol(linea);

    return LEIDO;
}

int leerSocioBin(T_Socio *socio, FILE *pf)
{
    return fread(socio, sizeof(T_Socio), 1, pf);
}

int guardarSocioBin(T_Socio *socio, FILE *pf)
{
    return fwrite(socio, sizeof(T_Socio), 1, pf);
}

int cmpDNI(const void* e1, const void* e2)
{
    long *a = (long*) e1;
    long *b = (long*) e2;

    return *a - *b;
}

void mostrarSocio(T_Socio* socio)
{
    printf("=========================================\n");
    printf("DNI                 : %ld\n", socio->dni);
    printf("Apellido           : %s\n", socio->ape);
    printf("Nombre             : %s\n", socio->nom);

    printf("Fecha Nacimiento   : %02d/%02d/%04d\n",
           socio->fNac.dia,
           socio->fNac.mes,
           socio->fNac.anio);

    printf("Sexo               : %c\n", socio->sexo);

    printf("Fecha Afiliacion   : %02d/%02d/%04d\n",
           socio->fAfi.dia,
           socio->fAfi.mes,
           socio->fAfi.anio);

    printf("Categoria          : %s\n", socio->cat);

    printf("Ultima Cuota       : %02d/%02d/%04d\n",
           socio->fUltCuota.dia,
           socio->fUltCuota.mes,
           socio->fUltCuota.anio);

    printf("Estado             : %c\n", socio->estado);

    if(socio->estado == 'B')
    {
        printf("Fecha Baja         : %02d/%02d/%04d\n",
               socio->fBaja.dia,
               socio->fBaja.mes,
               socio->fBaja.anio);
    }
    else
    {
        printf("Fecha Baja         : --/--/----\n");
    }

    printf("=========================================\n");
}

void mostrarSocioLinea(T_Socio* socio)
{
    printf("%-10ld %-20s %-20s %02d/%02d/%04d %c %-10s %02d/%02d/%04d %c ",
           socio->dni,
           socio->ape,
           socio->nom,
           socio->fNac.dia,
           socio->fNac.mes,
           socio->fNac.anio,
           socio->sexo,
           socio->cat,
           socio->fUltCuota.dia,
           socio->fUltCuota.mes,
           socio->fUltCuota.anio,
           socio->estado);

    if(socio->estado == 'B')
        printf("%02d/%02d/%04d",
               socio->fBaja.dia,
               socio->fBaja.mes,
               socio->fBaja.anio);
    else
        printf("----------");

    printf("\n");
}
