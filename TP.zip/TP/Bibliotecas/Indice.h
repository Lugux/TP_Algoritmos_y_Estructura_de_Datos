#ifndef INDICE_H_INCLUDED
#define INDICE_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Arbol.h"

#define OK 1
#define ERROR 0

typedef struct
{
    void *clave;
    unsigned nro_reg;
}reg_generico;

typedef struct
{
    FILE *pf;
    size_t tamClave;
}ctx_indice;

typedef struct
{
    void (*accion)(const void *, unsigned, void *);
    void *param;
} ctx_recorrer;

typedef struct
{
    T_Arbol ar_ind;
    size_t tamClave;
    int (*comp)(const void*, const void*);
}t_indice;

void ind_crear(t_indice* ind, size_t tam_clave, int (*cmp)(const void*, const void*));
int ind_insertar(t_indice* ind, void *clave, unsigned nro_reg);
int ind_eliminar(t_indice* ind, void *clave, unsigned *nro_reg);
int ind_buscar(const t_indice* ind, void *clave, unsigned *nro_reg);
int ind_cargar(t_indice* ind, const char* path);
int ind_grabar(const t_indice* ind, const char* path);
void ind_vaciar(t_indice* ind);
int ind_recorrer(const t_indice* ind, void (*accion)(const void *, unsigned, void *), void* param);

void eliminarRegistroIndice(void *info);

int cmpRegGenerico(const void *a, const void *b, void *ctx);

int leerRegistroIndice(void *ctx, void *info, unsigned pos);
void grabarRegistroIndice(void *info, void *ctx);
void recorrerRegistroIndice(void *info, void *ctx);

#endif // INDICE_H_INCLUDED
