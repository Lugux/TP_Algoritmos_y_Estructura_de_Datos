#include "Fecha.h"

void fechaActual(T_Fecha* fecha)
{
    time_t t = time(NULL);
    struct tm* tm = localtime(&t);
    fecha->dia = tm->tm_mday;
    fecha->mes = tm->tm_mon + 1;
    fecha->anio = tm->tm_year + 1900;
}

int compFechas(T_Fecha *f1, T_Fecha *f2)
{
    if (f1->anio != f2->anio)
        return f1->anio - f2->anio;
    if (f1->mes != f2->mes)
        return f1->mes - f2->mes;
    return f1->dia - f2->dia;
}

int validarFecha(T_Fecha *f)
{
    int diasPorMes[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

    if(f->anio < MIN_YEAR || f->anio > MAX_YEAR)
        return ERROR;

    if(f->mes < 1 || f->mes > 12)
        return ERROR;

    if(esBisiesto(f))
        diasPorMes[1] = 29;

    if(f->dia < 1 || f->dia > diasPorMes[f->mes - 1])
        return ERROR;

    return OK;
}

int esBisiesto(T_Fecha* f)
{
    return (f->anio%4==0 && f->anio%100!=0) || (f->anio%400==0);
}
