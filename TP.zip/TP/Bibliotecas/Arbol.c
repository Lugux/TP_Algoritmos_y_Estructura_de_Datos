#include "Arbol.h"

void crearArbol(T_Arbol* pa)
{
    (*pa) = NULL;
}

int insertarOrdenadoArbol(T_Arbol *pa, void *pd, size_t tam, int (*cmp)(const void*, const void*, void*), void *ctx)
{
    T_Nodo *nue;

    if(*pa)
    {
        int rc = cmp(pd, (*pa)->info, ctx);
        if(rc < 0)
            return insertarOrdenadoArbol(&(*pa)->izq, pd, tam, cmp, ctx);
        if(rc > 0)
            return insertarOrdenadoArbol(&(*pa)->der, pd, tam, cmp, ctx);
        else
            return ERROR;
    }

    if((nue = (T_Nodo*)malloc(sizeof(T_Nodo)))==NULL || (nue->info = malloc(tam))==NULL)
    {
        free(nue);
        return ERROR;
    }

    memcpy(nue->info, pd, tam);
    nue->tamInfo = tam;
    nue->izq = nue->der = NULL;
    *pa = nue;

    return OK;
}

void recorrerOrdenArbol(const T_Arbol * pa, void (*accion)(void*, void*), void* param)
{
    if(!*pa)
        return;
    recorrerOrdenArbol(&(*pa)->izq, accion, param);
    accion((*pa)->info, param);
    recorrerOrdenArbol(&(*pa)->der, accion, param);
}

void recorrerPreordenArbol(const T_Arbol * pa, void (*accion)(void*, void*), void* param)
{
    if(!*pa)
        return;
    accion((*pa)->info, param);
    recorrerPreordenArbol(&(*pa)->izq, accion, param);
    recorrerPreordenArbol(&(*pa)->der, accion, param);
}

void recorrerPosordenArbol(const T_Arbol * pa, void (*accion)(void*, void*), void* param)
{
    if(!*pa)
        return;
    recorrerPosordenArbol(&(*pa)->izq, accion, param);
    recorrerPosordenArbol(&(*pa)->der, accion, param);
    accion((*pa)->info, param);
}

unsigned contarNodosArbolBin(const T_Arbol *p)
{
    if(!*p)
        return 0;

    return contarNodosArbolBin(&(*p)->izq) + contarNodosArbolBin(&(*p)->der) + 1;
}

unsigned alturaArbolBin(const T_Arbol *p)
{
    if(!*p)
        return 0;

    unsigned a1 = alturaArbolBin(&(*p)->izq);
    unsigned a2 = alturaArbolBin(&(*p)->der);

    return ((a1 > a2) ? a1 : a2) + 1;
}

unsigned esBalanceado(const T_Arbol *p)
{
    return esCompletoHastaNivel(p, alturaArbolBin(p)-2);
}

int esCompletoHastaNivel(const T_Arbol *p, int n)
{
    if(!*p)
        return n<0;
    if(n==0)
        return 1;

    return esCompletoHastaNivel(&(*p)->izq, n-1) && esCompletoHastaNivel(&(*p)->der, n-1);
}

unsigned cantNodosHastaNivel(const T_Arbol *p, int n)
{
    if(!*p)
        return 0;
    if(n==0)
        return 1;

    return cantNodosHastaNivel(&(*p)->izq, n-1) + cantNodosHastaNivel(&(*p)->der, n-1) + 1;
}

int eliminarElementoArbol(T_Arbol *p, void *d, unsigned tam, int (*cmp)(const void*, const void*, void*), void *ctx, void(*eliminarDato)(void*))
{
    if(!(p = buscarNodoArbol(p, d, cmp, ctx)))
        return 0;

    memcpy(d, (*p)->info, MINIMO(tam, (*p)->tamInfo));
    return eliminarRaizArbol(p, eliminarDato);
}

int eliminarRaizArbol(T_Arbol *pa, void(*eliminarDato)(void*))
{
    T_Nodo **temp, *elim;
    void *infoVieja;

    if(!*pa)
        return ERROR;

    if(!(*pa)->izq && !(*pa)->der)
    {
        if(eliminarDato)
            eliminarDato((*pa)->info);

        free((*pa)->info);
        free(*pa);
        *pa = NULL;

        return OK;
    }

    infoVieja = (*pa)->info;

    temp = alturaArbolBin(&(*pa)->izq) > alturaArbolBin(&(*pa)->der) ?
           mayorNodoArbol(&(*pa)->izq) :
           menorNodoArbol(&(*pa)->der);

    elim = *temp;

    (*pa)->info = elim->info;
    (*pa)->tamInfo = elim->tamInfo;

    *temp = elim->izq ? elim->izq : elim->der;

    if(eliminarDato)
        eliminarDato(infoVieja);

    free(infoVieja);
    free(elim);

    return OK;
}

T_Nodo** mayorNodoArbol(const T_Arbol *pa)
{
    if(!*pa)
        return NULL;

    if(!(*pa)->der)
        return (T_Nodo**) pa;

    return mayorNodoArbol(&(*pa)->der);
}

T_Nodo** menorNodoArbol(const T_Arbol *pa)
{
    if(!*pa)
        return NULL;

    if(!(*pa)->izq)
        return (T_Nodo**) pa;

    return menorNodoArbol(&(*pa)->izq);
}

T_Nodo** buscarNodoArbol(const T_Arbol *pa, const void* pd, int (*cmp)(const void*, const void*, void*), void *ctx)
{
    int rc;

    if(!(*pa))
        return NULL;

    if(*pa && (rc = cmp(pd, (*pa)->info, ctx)))
    {
        if(rc < 0)
            return buscarNodoArbol(&(*pa)->izq, pd, cmp, ctx);

        return buscarNodoArbol(&(*pa)->der, pd, cmp, ctx);
    }

    return (T_Nodo**) pa;
}

void vaciarArbol(T_Arbol *pa, void(*eliminarDato)(void*))
{
    if(!*pa)
        return;

    vaciarArbol(&(*pa)->izq, eliminarDato);
    vaciarArbol(&(*pa)->der, eliminarDato);

    if(eliminarDato)
            eliminarDato((*pa)->info);

    free((*pa)->info);
    free(*pa);

    *pa = NULL;
}

int cargarDesdeDatosOrdenadosRec(T_Arbol *pa, void *pf, int (*leer)(void *, void *, unsigned ), int li, int ls, size_t tam)
{
    int m = (li+ls)/2, r;

    if (li>ls)
        return OK;

    if (!reservarMemoriaNodo(*pa, sizeof(T_Nodo), (*pa)->info, tam))
        return ERROR;

    if (!leer(pf, (*pa)->info, m))
    {
        free((*pa)->info);
        free(*pa);
        return ERROR;
    }
    (*pa)->tamInfo = tam;
    (*pa)->izq = (*pa)->der = NULL;

    if((r = cargarDesdeDatosOrdenadosRec(&(*pa)->izq, pf, leer, li, m-1, tam)) != OK)
        return r;
    return cargarDesdeDatosOrdenadosRec(&(*pa)->der, pf, leer, m+1, ls, tam);
}
