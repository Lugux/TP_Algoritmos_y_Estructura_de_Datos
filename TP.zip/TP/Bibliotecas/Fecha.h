#ifndef FECHA_H_INCLUDED
#define FECHA_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define OK 1
#define ERROR 0

#define MIN_YEAR 1900
#define MAX_YEAR 2036

typedef struct
{
    int anio, mes, dia;
}T_Fecha;

void fechaActual(T_Fecha *fecha);

int compFechas(T_Fecha *f1, T_Fecha *f2);
int validarFecha(T_Fecha *f);
int esBisiesto(T_Fecha* f);

#endif // FECHA_H_INCLUDED
