#ifndef SOCIO_H_INCLUDED
#define SOCIO_H_INCLUDED

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Fecha.h"

#define ERROR 0
#define OK 1
#define MENOR 2
#define ADULTO 3
#define LEIDO 1
#define FIN_ARCH 0
#define REG_ERROR -1

#define ERR_DNI 2
#define ERR_APELLIDO 3
#define ERR_NOMBRE 4
#define ERR_FECHA_NAC 5
#define ERR_SEXO 6
#define ERR_FECHA_AFI 7
#define ERR_CATEGORIA 8
#define ERR_FECHA_CUOTA 9
#define ERR_ESTADO 10
#define ERR_FECHA_BAJA 11

typedef struct
{
    long dni;
    char ape[61], nom[61], cat[11];
    T_Fecha fNac, fAfi, fUltCuota, fBaja;
    char sexo, estado;
}T_Socio;

int leerSocioTxt(T_Socio *socio, FILE *pf);
int leerSocioBin(T_Socio *socio, FILE *pf);
int guardarSocioBin(T_Socio *socio, FILE *pf);

int validarDNI(long dni);
int validarApellido(const char *ape);
int validarNombre(const char *nom);
int validarFechaNac(T_Fecha *f, T_Fecha *fAct);
int validarSexo(char s);
int validarFechaAfiliacion(T_Socio *socio, T_Fecha *fAct);
int validarCategoria(T_Socio *socio, T_Fecha *fAct);
int validarFechaUltimaCuota(T_Socio *socio, T_Fecha *fAct);
int validarEstado(char e);
int validarFechaBaja(T_Socio *socio, T_Fecha *fAct);
int esMenor(T_Socio *socio, T_Fecha *fAct);

int validarSocio(T_Socio* socio, T_Fecha *fAct);

void mostrarSocio(T_Socio* socio);
void mostrarSocioLinea(T_Socio* socio);

int cmpDNI(const void*, const void*);

#endif // SOCIO_H_INCLUDED
