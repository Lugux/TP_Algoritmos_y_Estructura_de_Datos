#ifndef DEPENDENCIAS_H_INCLUDED
#define DEPENDENCIAS_H_INCLUDED

#include "../../Bibliotecas/Indice.h"
#include "../../Bibliotecas/Arbol.h"
#include "../../Bibliotecas/Socio.h"
#include "../../Bibliotecas/Fecha.h"

#define NOM_ARCH_BIN "../../Archivos/socios.dat"
#define NOM_ARCH_IDX "../../Archivos/socios.idx"
#define NOM_ARCH_ERROR "../../Archivos/error.txt"

void pedirPath(char*);
int leerTXTyGrabarBin(t_indice*, const char*);
int tieneEncabezado(FILE *pf);
const char *mensajeErrorSocio(int);
int guardarInd(const t_indice*);
#endif // DEPENDENCIAS_H_INCLUDED
