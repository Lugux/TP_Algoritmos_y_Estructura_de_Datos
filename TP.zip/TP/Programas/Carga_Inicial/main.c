#include "Dependencias.h"

int main()
{
    char inicio[100] = "../../Archivos/";
    t_indice ind;

    pedirPath(inicio);

    ind_crear(&ind, sizeof(long), cmpDNI);

    if(!leerTXTyGrabarBin(&ind, inicio))
        exit(ERROR);

    if(!guardarInd(&ind))
        exit(ERROR);

    ind_vaciar(&ind);

    return OK;
}
