#include "Dependencias.h"

void pedirPath(char* path)
{
    char nombre[100], *aux;

    printf("Ingrese el nombre del archivo CSV: ");
    fgets(nombre,sizeof(nombre),stdin);

    aux = strchr(nombre, '\n');

    if(aux)
        *aux = '\0';

    strcat(path,nombre);
}

int leerTXTyGrabarBin(t_indice* ind, const char* path)
{
    FILE *pfTxt, *pfBin, *pfError;
    char linea[300];
    T_Socio socio;
    T_Fecha fechaHoy;
    unsigned nroReg = 0, cont = 0;
    int estado, res;

    fechaActual(&fechaHoy);

    pfTxt = fopen(path, "rt");
    if(!pfTxt)
        return ERROR;

    pfBin = fopen(NOM_ARCH_BIN, "wb");
    if(!pfBin)
    {
        fclose(pfTxt);
        return ERROR;
    }

    pfError = fopen(NOM_ARCH_ERROR, "wt");
    if(!pfError)
    {
        fclose(pfTxt);
        fclose(pfBin);
        return ERROR;
    }

    if(tieneEncabezado(pfTxt))
        fgets(linea,sizeof(linea),pfTxt);

    while((estado = leerSocioTxt(&socio, pfTxt)) != FIN_ARCH)
    {

        if(estado == REG_ERROR)
        {
            fprintf(pfError,
                    "Registro %u: Error de formato\n",
                    cont + 1);

            cont++;
            continue;
        }

        res = validarSocio(&socio, &fechaHoy);

        if(res != OK)
        {
            fprintf(pfError,
                    "Registro %u - DNI %ld: %s\n",
                    cont + 1,
                    socio.dni,
                    mensajeErrorSocio(res));

            cont++;
            continue;
        }

        unsigned regEncontrado;

        if(ind_buscar(ind, &socio.dni, &regEncontrado))
        {
            fprintf(pfError,
                    "Registro %u - DNI %ld: DNI duplicado\n",
                    cont + 1,
                    socio.dni);

            cont++;
            continue;
        }

        if(!ind_insertar(ind, &socio.dni, nroReg))
        {
            fclose(pfTxt);
            fclose(pfBin);
            fclose(pfError);
            return ERROR;        // error interno (memoria)
        }

        guardarSocioBin(&socio, pfBin);

        nroReg++;
        cont++;
    }
    fclose(pfTxt);
    fclose(pfBin);
    fclose(pfError);

    printf("\n");
    printf("====================================\n");
    printf("Transformacion finalizada\n");
    printf("====================================\n");
    printf("Registros procesados : %u\n", cont);
    printf("Registros grabados   : %u\n", nroReg);
    printf("Registros con error  : %u\n", cont - nroReg);
    printf("====================================\n");

    return OK;
}

int tieneEncabezado(FILE *pf)
{
    char linea[300];
    char *fin;
    long dni;

    long pos = ftell(pf);

    if(!fgets(linea,sizeof(linea),pf))
        return FIN_ARCH;

    fin = strchr(linea,',');

    if(!fin)
    {
        fseek(pf,pos,SEEK_SET);
        return 0;
    }

    *fin='\0';

    dni = atol(linea);

    fseek(pf,pos,SEEK_SET);

    return dni==0;
}

const char *mensajeErrorSocio(int r)
{
    switch(r)
    {
        case ERR_DNI:
            return "DNI invalido";

        case ERR_APELLIDO:
            return "APELLIDO invalido";

        case ERR_NOMBRE:
            return "NOMBRE invalido";

        case ERR_FECHA_NAC:
            return "Fecha de nacimiento invalida";

        case ERR_SEXO:
            return "Sexo invalido";

        case ERR_FECHA_AFI:
            return "Fecha de afiliacion invalida";

        case ERR_CATEGORIA:
            return "Categoria incompatible";

        case ERR_FECHA_CUOTA:
            return "Fecha de ultima cuota invalida";

        case ERR_ESTADO:
            return "Estado invalido";

        case ERR_FECHA_BAJA:
            return "Fecha de baja invalida";
    }

    return "Error desconocido";
}

int guardarInd(const t_indice* ind)
{
    return ind_grabar(ind, NOM_ARCH_IDX);
}
