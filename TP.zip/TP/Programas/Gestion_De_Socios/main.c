#include "Dependencias.h"

int main()
{
    FILE * arch;
    const char opciones [][TAM_MENU] = {"AMBLCS",
                                        "Alta",
                                        "Modificar",
                                        "Baja",
                                        "Listar Socios Activos Ordenados",
                                        "Compactar y Reindexar",
                                        "Salir"};
    char op;
    t_indice indice;

    arch = fopen(NOM_ARCH_BIN, "r+b");
    if (!arch)
        exit(1);

    ind_crear(&indice, sizeof(long), cmpDNI);

    if(ind_cargar(&indice, NOM_ARCH_IDX)==ERROR_ARCHIVO)
    {
        puts("No se pudo cargar el indice");
        fclose(arch);
        exit(1);
    }

    do{
        op=menu(opciones, "Menu Principal");
        system("cls");
        switch (op)
        {
            case 'A':
                opAlta(arch, &indice);
                pausa();
                break;
            case 'M':
                opModificar(arch, &indice);
                pausa();
                break;
            case 'B':
                opBaja(arch, &indice);
                pausa();
                break;
            case 'L':
                opListarSocios(arch, &indice);
                pausa();
                break;
            case 'C':
                opCompactarYReindexar(&arch, &indice, NOM_ARCH_BIN);
                pausa();
                break;
        }
    }while(op!='S');
    ind_grabar(&indice, NOM_ARCH_IDX);
    ind_vaciar(&indice);
    fclose(arch);
    return TODO_OK;
}
