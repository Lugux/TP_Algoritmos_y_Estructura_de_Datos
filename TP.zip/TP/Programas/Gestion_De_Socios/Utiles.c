#include "Dependencias.h"

char menu(const char m[][TAM_MENU], const char * titulo)
{
    int i, cantop;
    char op;
    cantop = strlen(m[0]);
    do
    {
        system("cls");

        printf("=========================================\n");
        printf("%s\n", titulo);
        printf("=========================================\n");

        for(i = 1; i <= cantop; i++)
            printf("%c) %s\n", m[0][i-1], m[i]);

        printf("\nOpcion: ");
        scanf(" %c", &op);

        op = toupper(op);

    }while(!strchr(m[0], op));

    return op;
}

void opAlta(FILE * pf, t_indice * ind)
{
    T_Socio socio;
    unsigned nroReg;
    T_Fecha hoy;

    fechaActual(&hoy);

    ingresarSocio(&socio, &hoy);

    if(ind_buscar(ind,&socio.dni,&nroReg)==OK)
    {
        imprimirMensaje(DUPLICADO);
        return;
    }

    fseek(pf, 0L, SEEK_END);

    nroReg = (unsigned)(ftell(pf) / sizeof(T_Socio));

    if(!ind_insertar(ind,&socio.dni,nroReg))
    {
        imprimirMensaje(SIN_MEM);
        return;
    }

    if(!guardarSocioBin(&socio,pf))
    {
        ind_eliminar(ind,&socio.dni,&nroReg);

        imprimirMensaje(ERROR_ARCHIVO);
        return;
    }

    imprimirMensaje(TODO_OK);
}

void opBaja(FILE * pf, t_indice * ind)
{
    long dni;
    unsigned nroReg;
    T_Socio socio;
    T_Fecha hoy;

    fechaActual(&hoy);

    printf("\n========== BAJA DE SOCIO ==========\n");
    printf("DNI: ");
    scanf("%ld", &dni);

    if(ind_buscar(ind, &dni, &nroReg) == ERROR)
    {
        imprimirMensaje(NO_EXISTE);
        return;
    }

    fseek(pf, nroReg * sizeof(T_Socio), SEEK_SET);

    if(!leerSocioBin(&socio, pf))
    {
        imprimirMensaje(ERROR_ARCHIVO);
        return;
    }

    socio.estado = 'B';
    socio.fBaja = hoy;

    fseek(pf, nroReg * sizeof(T_Socio), SEEK_SET);

    if(!guardarSocioBin(&socio, pf))
    {
        imprimirMensaje(ERROR_ARCHIVO);
        return;
    }

    ind_eliminar(ind, &dni, &nroReg);

    imprimirMensaje(TODO_OK);
}

void opModificar(FILE *pf, t_indice *ind)
{
    long dni;
    unsigned nroReg;
    T_Socio socio;
    T_Fecha hoy;

    fechaActual(&hoy);

    printf("\n========== MODIFICAR SOCIO ==========\n");
    printf("DNI: ");
    scanf("%ld", &dni);

    if(ind_buscar(ind, &dni, &nroReg) == ERROR)
    {
        imprimirMensaje(NO_EXISTE);
        return;
    }

    fseek(pf, nroReg * sizeof(T_Socio), SEEK_SET);

    if(!leerSocioBin(&socio, pf))
    {
        imprimirMensaje(ERROR_ARCHIVO);
        return;
    }

    puts("\nDatos actuales:");
    mostrarSocio(&socio);

    modificarSocio(&socio, &hoy);

    fseek(pf, nroReg * sizeof(T_Socio), SEEK_SET);

    if(!guardarSocioBin(&socio, pf))
    {
        imprimirMensaje(ERROR_ARCHIVO);
        return;
    }

    imprimirMensaje(TODO_OK);
}

void opListarSocios(FILE *pf, t_indice *ind)
{
    printf("\n========== LISTADO DE SOCIOS ==========\n\n");

    rewind(pf);

    ind_recorrer(ind, mostrarRegistro, pf);
}

void opCompactarYReindexar(FILE **pf, t_indice *ind, const char *nomArch)
{
    FILE *tmp;
    T_Socio socio;
    unsigned nroRegNuevo = 0;

    tmp = fopen("temp.dat", "wb");

    if(!tmp)
    {
        imprimirMensaje(ERROR_ARCHIVO);
        return;
    }

    rewind(*pf);

    ind_vaciar(ind);

    while(leerSocioBin(&socio, *pf))
    {
        if(socio.estado == 'A')
        {
            guardarSocioBin(&socio, tmp);

            if(!ind_insertar(ind, &socio.dni, nroRegNuevo))
            {
                fclose(tmp);
                imprimirMensaje(SIN_MEM);
                return;
            }

            nroRegNuevo++;
        }
    }

    fclose(*pf);
    fclose(tmp);

    remove(nomArch);
    rename("temp.dat", nomArch);

    *pf = fopen(nomArch, "r+b");

    ind_grabar(ind, NOM_ARCH_IDX);

    imprimirMensaje(TODO_OK);
}

void imprimirMensaje(int res)
{
    switch(res)
    {
        case TODO_OK: puts("Operacion realizada correctamente.");
                break;
        case SIN_MEM: puts("Error de memoria.");
                break;
        case ERROR_ARCHIVO: puts("Error en el archivo.");
                break;
        case DUPLICADO: puts("Resgistro duplicado.");
                break;
        case NO_EXISTE: puts("Resgistro inexistente.");
                break;
    }
}

void ingresarSocio(T_Socio *socio, T_Fecha *hoy)
{
    int estado = 0;
    char *aux;
    printf("\n========== ALTA DE SOCIO ==========\n");

    /* DNI */
    do
    {
        printf("DNI: ");
        scanf("%ld", &socio->dni);

        estado = !validarDNI(socio->dni);

        if(estado)
            printf("DNI invalido, ingrese nuevamente.\n");

    }while(estado);

    limpiarBuffer();

    estado = 0;
    /* Apellido */
    do
    {
        printf("Apellido: ");
        fgets(socio->ape, sizeof(socio->ape), stdin);
        aux = strchr(socio->ape, '\n');

        if(aux)
            *aux = '\0';

        estado = strlen(socio->ape) == 0;
        if(estado)
            printf("El apellido no puede estar vacio.\n");

    }while(estado);

    estado = 0;
    /* Nombre */
    do
    {
        printf("Nombre: ");
        fgets(socio->nom, sizeof(socio->nom), stdin);
        aux = strchr(socio->nom, '\n');

        if(aux)
            *aux = '\0';

        estado = strlen(socio->nom) == 0;

        if(estado)
            printf("El nombre no puede estar vacio.\n");

    }while(estado);

    estado = 0;
    /* Fecha nacimiento */
    do
    {
        ingresarFecha("Fecha de nacimiento (dd/mm/aaaa): ", &socio->fNac);

        estado = !validarFechaNac(&socio->fNac, hoy);

        if(estado)
            printf("Fecha invalida, ingrese nuevamente.\n");

    }while(estado);

    estado = 0;

    /* Sexo */
    do
    {
        printf("Sexo (M/F/O): ");
        scanf(" %c", &socio->sexo);

        socio->sexo = toupper((unsigned char)socio->sexo);

        estado = !validarSexo(socio->sexo);

        if(estado)
            printf("Sexo invalido, ingrese nuevamente.\n");

    }while(estado);

    limpiarBuffer();

    estado = 0;

    /* Fecha afiliacion */
    do
    {
        ingresarFecha("Fecha de afiliacion (dd/mm/aaaa): ", &socio->fAfi);

        estado = !validarFechaAfiliacion(socio, hoy);

        if(estado)
            printf("Fecha invalida, ingrese nuevamente.\n");

    }while(estado);

    estado = 0;

    /* Categoria */
    do
    {
        printf("Categoria (MENOR, CADETE, ADULTO, VITALICIO, HONORARIO, JUBILADO): ");

        fgets(socio->cat, sizeof(socio->cat), stdin);
        aux = strchr(socio->cat, '\n');

        if(aux)
            *aux = '\0';

        pasarAMayusculas(socio->cat);

        estado = !validarCategoria(socio, hoy);

        if(estado)
            printf("Categoria invalida, ingrese nuevamente.\n");

    }while(estado);

    estado = 0;

    /* Fecha �ltima cuota */
    do
    {
        ingresarFecha("Fecha de ultima cuota (dd/mm/aaaa): ", &socio->fUltCuota);

        estado = !validarFechaUltimaCuota(socio, hoy);
        if(estado)
            printf("Fecha invalida, ingrese nuevamente.\n");

    }while(estado);

    socio->estado = 'A';

    socio->fBaja.dia = 0;
    socio->fBaja.mes = 0;
    socio->fBaja.anio = 0;
}

void pasarAMayusculas(char *cad)
{
    while(*cad)
    {
        *cad = toupper(*cad);
        cad++;
    }
}

void ingresarFecha(const char *mensaje, T_Fecha *f)
{
    printf("%s", mensaje);
    if(scanf("%d/%d/%d", &f->dia, &f->mes, &f->anio) != 3)
    {
        f->dia = 0;
        f->mes = 0;
        f->anio = 0;
    }

    limpiarBuffer();
}

void limpiarBuffer(void)
{
    while(getchar() != '\n');
}

void pausa(void)
{
    printf("\nPresione ENTER para continuar...");
    limpiarBuffer();
    getchar();
}

void modificarSocio(T_Socio *socio, T_Fecha *hoy)
{
    int estado;
    char *aux;

    printf("\n========== MODIFICAR SOCIO ==========\n");

    /* Apellido */
    do
    {
        printf("Apellido [%s]: ", socio->ape);

        fgets(socio->ape, sizeof(socio->ape), stdin);

        aux = strchr(socio->ape, '\n');
        if(aux)
            *aux = '\0';

        estado = strlen(socio->ape) == 0;

        if(estado)
            printf("El apellido no puede estar vacio.\n");

    }while(estado);

    /* Nombre */
    do
    {
        printf("Nombre [%s]: ", socio->nom);

        fgets(socio->nom, sizeof(socio->nom), stdin);

        aux = strchr(socio->nom, '\n');
        if(aux)
            *aux = '\0';

        estado = strlen(socio->nom) == 0;

        if(estado)
            printf("El nombre no puede estar vacio.\n");

    }while(estado);

    /* Sexo */
    do
    {
        printf("Sexo (%c): ", socio->sexo);

        scanf(" %c", &socio->sexo);
        socio->sexo = toupper(socio->sexo);

        limpiarBuffer();

        estado = !validarSexo(socio->sexo);

        if(estado)
            printf("Sexo invalido.\n");

    }while(estado);

    /* Categoria */
    do
    {
        printf("Categoria [%s]: ", socio->cat);

        fgets(socio->cat, sizeof(socio->cat), stdin);

        aux = strchr(socio->cat, '\n');
        if(aux)
            *aux = '\0';

        pasarAMayusculas(socio->cat);

        estado = !validarCategoria(socio, hoy);

        if(estado)
            printf("Categoria invalida.\n");

    }while(estado);

    /* Fecha ultima cuota */
    do
    {
        ingresarFecha("Fecha ultima cuota (dd/mm/aaaa): ",
                      &socio->fUltCuota);

        estado = !validarFechaUltimaCuota(socio, hoy);

        if(estado)
            printf("Fecha invalida.\n");

    }while(estado);
}

void mostrarRegistro(const void *clave, unsigned nroReg, void *param)
{
    FILE *pf = (FILE*)param;
    T_Socio socio;

    fseek(pf, nroReg * sizeof(T_Socio), SEEK_SET);

    if(leerSocioBin(&socio, pf))
        mostrarSocioLinea(&socio);
}
