#ifndef DEPENDENCIAS_H_INCLUDED
#define DEPENDENCIAS_H_INCLUDED

#include "../../Bibliotecas/Indice.h"
#include "../../Bibliotecas/Arbol.h"
#include "../../Bibliotecas/Socio.h"
#include "../../Bibliotecas/Fecha.h"
#include <ctype.h>

#define NOM_ARCH_BIN "../../Archivos/socios.dat"
#define NOM_ARCH_IDX "../../Archivos/socios.idx"

#define TAM_MENU 40

#define TODO_OK 1
#define ERROR_ARCHIVO 0
#define SIN_MEM -1
#define DUPLICADO -2
#define NO_EXISTE -3
#define INVALIDO -4

char menu(const char m[][TAM_MENU], const char *);
void opAlta(FILE * , t_indice * );
void opBaja(FILE * , t_indice * );
void opModificar(FILE * , t_indice * );
void opListarSocios(FILE * , t_indice * );
void opCompactarYReindexar(FILE ** , t_indice * , const char * );
void imprimirMensaje(int);

void ingresarSocio(T_Socio *socio, T_Fecha *hoy);
void ingresarFecha(const char *mensaje, T_Fecha *f);
void pasarAMayusculas(char *cad);

void modificarSocio(T_Socio *socio, T_Fecha *hoy);

void mostrarRegistro(const void *clave, unsigned nroReg, void *param);

void limpiarBuffer(void);
void pausa(void);

#endif // DEPENDENCIAS_H_INCLUDED
